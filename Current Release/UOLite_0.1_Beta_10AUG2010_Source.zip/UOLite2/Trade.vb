﻿'Going to be an implementation of the trading system, for in-game secure trades.

Partial Class LiteClient

End Class
