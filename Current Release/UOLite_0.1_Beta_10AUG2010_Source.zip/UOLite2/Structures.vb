﻿'Common end-user accessable structures.

Public Structure CharListEntry
    Public Name As String
    Public Password As String
    Public Slot As Byte
End Structure