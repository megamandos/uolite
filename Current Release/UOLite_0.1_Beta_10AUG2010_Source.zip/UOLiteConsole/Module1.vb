﻿Imports UOLite2

Module Module1
    Public WithEvents Client As New LiteClient

    Sub Main()

    End Sub

End Module
